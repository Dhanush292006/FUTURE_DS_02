# Power BI Layout Guide
Page Name: Campaign Performance Overview

1. Top Section (KPIs)
   - Total Impressions (Card)
   - Total Clicks (Card)
   - CTR (Card)
   - Spend (Card)
   - CPC, CPM (Cards)
   - Conversions, CPA, ROAS, ROI (Cards)

2. Middle Section
   - Trend: Impressions, Clicks, Conversions over time (Line chart)
   - Spend vs Revenue (Clustered column chart)

3. Bottom Section
   - Best Campiagns (Bar chart)
   - Platform Comparison (Pie chart)
   - Age/Gender Performance (Bar chart)
