# How to Create PBIX
1. Open Power BI Desktop.
2. Load sample_ads_data.csv.
3. Go to Modeling -> New Measure -> Paste DAX.
4. Insert KPI cards and assign measures.
5. Add line charts, bar charts, pie charts as per layout guide.
6. Import Theme.json via View > Themes > Import.
7. Format everything clean & publish to Power BI Service.
