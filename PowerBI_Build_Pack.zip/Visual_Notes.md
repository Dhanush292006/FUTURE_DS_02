# Visual Notes
- Use clean KPI cards with bold numbers.
- Use modern fonts (Segoe UI).
- Minimize gridlines.
- Use consistent color palette.
- Use tooltip pages for deeper insights.
